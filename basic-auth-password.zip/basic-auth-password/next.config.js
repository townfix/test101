const withTM = require('@vercel/examples-ui/transpile')()

module.exports = withTM()
